# Teacher Nelly's Young Learners Academy — Android App

This project wraps the supplied `index.html` in a native Android WebView shell while preserving the existing React/Tailwind academy experience.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync/download the Android Gradle Plugin and SDK components.
3. Connect an Android phone or start an emulator.
4. Run the `app` configuration.
5. For an installable APK: **Build → Build APK(s)**.

## Important
The supplied HTML uses online CDNs for React, Tailwind CSS, Font Awesome and Google Fonts, so the app needs internet access for those resources. The app itself loads the academy HTML locally from `assets/index.html`.
